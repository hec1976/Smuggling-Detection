# HTML Smuggling Detection v4.7.0 – komplette Tests 01 bis 68

Diese Sammlung enthält die vollständige HTML-/Script-Regressionssuite.

## Bestand
- Tests 01–56: v4.6.0-Kern- und Erweiterungstests
- Tests 57–68: neue v4.7.0-Regressionspfade

## Neu in v4.7.0
57. DOM Dynamic Sink
58. Dynamic `import()` aus `data:`
59. Worker Blob + statische Worker-Script-Rekonstruktion
60. ServiceWorker `register()` + Root Scope
61. WebSocket-Portscan
62. JSFuck-Heuristik
63. Unicode-Escape-Rekonstruktion
64. Template-Literal-Obfuskation
65. ZIP-Kommentar-Payload
66. ZIP-Stored-Entry-Entropie
67. Stored ZIP-in-ZIP Rekursion
68. SharedArrayBuffer/Atomics Timing

Die eingebetteten Binärdaten sind synthetische Testdaten und keine ausführbaren Schadprogramme.

Die Sollwerte stehen in `test_manifest_01-68.csv` und `test_manifest_01-68.json`.

Echte Attachment-Dateinamen, MIME-Typen, Newsletter-Header und Rspamd-Maps benötigen weiterhin eine separate EML-/MIME-Suite.
