# HTML Smuggling Detection v4.6.0 – komplette Tests 01 bis 56

Enthalten sind alle HTML-/Script-Regressionstests 01–56.

## Gruppen
- 01–15: Kernpfade, Decode, PDF, SVG, CHM, HTA
- 16–20: Zertifikat und CSS Code Execution
- 21–35: External Scripts, CSS Exfil, Geo, Evasion, Persistence, Rotation, ClickFix, Push, Blockchain
- 36–38: Negative / Newsletter-HTML
- 39–40: All-in-One und SVG Data URI
- 41–42: v4.6 Script-Prescan und Budget
- 43–45: v4.6 Uint8Array / Nested Base64 / GZIP
- 46–54: v4.6 ZIP-Parser
- 55–56: v4.6 XOR-/RC4-Rekonstruktion

Die eingebetteten Binärdaten sind synthetische Testdaten und keine ausführbaren Schadprogramme.

Sollwerte:
- test_manifest_01-56.csv
- test_manifest_01-56.json

Hinweis:
Echte MIME-Part-, Attachment-Dateinamen-, Newsletter-Header- und Map-Tests benötigen weiterhin eine separate EML-/MIME-Suite.
